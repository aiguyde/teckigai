from typing import List, Dict, Tuple
import numpy as np
from questions_pool import UserType, CareerCategory, career_paths

class EnhancedScoring:
    def __init__(self):
        self.user_type_weights = {
            UserType.NEWBIE: {
                CareerCategory.NO_CODE: 1.2,
                CareerCategory.CONTENT: 1.1,
                CareerCategory.SUPPORT: 1.1,
                CareerCategory.DESIGN: 0.9,
                CareerCategory.CODING: 0.7
            },
            UserType.BEGINNER: {
                CareerCategory.NO_CODE: 1.1,
                CareerCategory.CONTENT: 1.0,
                CareerCategory.SUPPORT: 1.0,
                CareerCategory.DESIGN: 1.0,
                CareerCategory.CODING: 0.9
            },
            UserType.CAREER_SWITCHER: {
                CareerCategory.NO_CODE: 1.0,
                CareerCategory.CONTENT: 1.0,
                CareerCategory.SUPPORT: 0.9,
                CareerCategory.DESIGN: 1.1,
                CareerCategory.CODING: 1.0
            },
            UserType.EXPERIENCED: {
                CareerCategory.NO_CODE: 0.8,
                CareerCategory.CONTENT: 0.9,
                CareerCategory.SUPPORT: 0.7,
                CareerCategory.DESIGN: 1.1,
                CareerCategory.CODING: 1.3
            }
        }

    def calculate_career_scores(
        self,
        user_type: UserType,
        answers: List[Dict],
        personality_traits: Dict[str, float] = None
    ) -> List[Tuple[str, float, List[str]]]:
        """
        Calculate career scores using an enhanced algorithm that considers:
        - User type weights
        - Answer patterns
        - Personality traits (if available)
        - Cross-category influences
        """
        base_scores = self._calculate_base_scores(answers)
        weighted_scores = self._apply_user_type_weights(base_scores, user_type)
        
        if personality_traits:
            weighted_scores = self._apply_personality_weights(weighted_scores, personality_traits)
        
        # Apply cross-category influences
        final_scores = self._apply_cross_category_influences(weighted_scores)
        
        # Get top roles for each category
        return self._get_top_roles(final_scores)

    def _calculate_base_scores(self, answers: List[Dict]) -> Dict[str, float]:
        """Calculate initial scores for each career category based on answers."""
        scores = {category.value: 0.0 for category in CareerCategory}
        
        for answer in answers:
            question_id = answer.get("question_id")
            answer_index = answer.get("answer_index")
            
            # Get question weights from questions_pool
            if question_id.startswith("d"):
                self._update_design_score(scores, answer_index)
            elif question_id.startswith("c"):
                self._update_coding_score(scores, answer_index)
            elif question_id.startswith("nc"):
                self._update_nocode_score(scores, answer_index)
            elif question_id.startswith("cc"):
                self._update_content_score(scores, answer_index)
        
        return scores

    def _apply_user_type_weights(
        self,
        scores: Dict[str, float],
        user_type: UserType
    ) -> Dict[str, float]:
        """Apply user type-specific weights to scores."""
        weights = self.user_type_weights[user_type]
        return {
            category: score * weights[CareerCategory(category)]
            for category, score in scores.items()
        }

    def _apply_personality_weights(
        self,
        scores: Dict[str, float],
        traits: Dict[str, float]
    ) -> Dict[str, float]:
        """Apply personality trait weights to scores."""
        # Example personality traits influence
        trait_weights = {
            "openness": {
                "design": 1.2,
                "coding": 1.1,
                "content": 1.1
            },
            "conscientiousness": {
                "coding": 1.2,
                "support": 1.1
            },
            "extraversion": {
                "content": 1.2,
                "support": 1.1
            }
        }
        
        weighted_scores = scores.copy()
        for trait, trait_score in traits.items():
            if trait in trait_weights:
                for category, weight in trait_weights[trait].items():
                    if category in weighted_scores:
                        weighted_scores[category] *= 1 + (weight - 1) * trait_score
        
        return weighted_scores

    def _apply_cross_category_influences(
        self,
        scores: Dict[str, float]
    ) -> Dict[str, float]:
        """Apply influences between related categories."""
        influences = {
            "design": {"coding": 0.2, "content": 0.2},
            "coding": {"no_code": 0.3},
            "content": {"support": 0.2},
            "no_code": {"support": 0.2}
        }
        
        final_scores = scores.copy()
        for category, related in influences.items():
            for related_category, influence_weight in related.items():
                if scores[category] > scores[related_category]:
                    final_scores[related_category] += scores[category] * influence_weight
        
        return final_scores

    def _get_top_roles(
        self,
        scores: Dict[str, float]
    ) -> List[Tuple[str, float, List[str]]]:
        """Get top roles based on category scores."""
        # Normalize scores to percentages
        total = sum(scores.values())
        normalized_scores = {k: (v/total) * 100 for k, v in scores.items()}
        
        # Sort categories by score
        sorted_categories = sorted(
            normalized_scores.items(),
            key=lambda x: x[1],
            reverse=True
        )
        
        # Get top roles for each category
        recommendations = []
        for category, score in sorted_categories[:3]:
            roles = career_paths[category]["roles"]
            skills = career_paths[category]["skills"]
            recommendations.append((category, score, roles[:3]))
        
        return recommendations

    def _update_design_score(self, scores: Dict[str, float], answer_index: int):
        """Update design-related scores based on answer."""
        weights = [1.0, 0.7, 0.3, 0.1]
        scores["design"] += weights[answer_index]

    def _update_coding_score(self, scores: Dict[str, float], answer_index: int):
        """Update coding-related scores based on answer."""
        weights = [1.0, 0.6, 0.2, 0.1]
        scores["coding"] += weights[answer_index]

    def _update_nocode_score(self, scores: Dict[str, float], answer_index: int):
        """Update no-code-related scores based on answer."""
        weights = [1.0, 0.8, 0.3, 0.5]
        scores["no_code"] += weights[answer_index]

    def _update_content_score(self, scores: Dict[str, float], answer_index: int):
        """Update content-related scores based on answer."""
        weights = [1.0, 0.7, 0.3, 0.2]
        scores["content"] += weights[answer_index]

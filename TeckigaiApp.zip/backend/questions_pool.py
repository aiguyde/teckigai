from typing import List, Dict
from enum import Enum

class UserType(Enum):
    NEWBIE = "newbie"
    BEGINNER = "beginner"
    CAREER_SWITCHER = "career_switcher"
    EXPERIENCED = "experienced"

class CareerCategory(Enum):
    DESIGN = "design"
    CODING = "coding"
    NO_CODE = "no_code"
    CONTENT = "content"
    SUPPORT = "support"

# Questions to determine user type
user_type_questions = [
    {
        "id": "ut1",
        "question": "What's your current experience level with online work?",
        "options": [
            {"text": "No experience at all", "weight": {"newbie": 5}},
            {"text": "Some basic knowledge but no work experience", "weight": {"beginner": 5}},
            {"text": "Experienced in another field, new to tech", "weight": {"career_switcher": 5}},
            {"text": "Already working in tech/online", "weight": {"experienced": 5}}
        ]
    },
    {
        "id": "ut2",
        "question": "What's your primary motivation for pursuing an online career?",
        "options": [
            {"text": "Exploring new opportunities", "weight": {"newbie": 3, "beginner": 2}},
            {"text": "Building basic skills", "weight": {"beginner": 3}},
            {"text": "Career transition", "weight": {"career_switcher": 4}},
            {"text": "Skill enhancement", "weight": {"experienced": 4}}
        ]
    },
    {
        "id": "ut3",
        "question": "How much time can you dedicate to learning?",
        "options": [
            {"text": "Just starting to explore (1-2 hours/week)", "weight": {"newbie": 3}},
            {"text": "Part-time (5-10 hours/week)", "weight": {"beginner": 3, "career_switcher": 2}},
            {"text": "Full-time dedication", "weight": {"career_switcher": 3, "experienced": 3}},
            {"text": "Already working, looking to upskill", "weight": {"experienced": 4}}
        ]
    }
]

# Career-specific questions
career_assessment_questions = [
    # Design Orientation Questions
    {
        "id": "d1",
        "category": "design",
        "question": "How do you feel about visual creativity and design?",
        "options": [
            {"text": "Love creating visual content", "weight": {"design": 5}},
            {"text": "Enjoy it but not my strength", "weight": {"design": 2, "content": 2}},
            {"text": "Prefer technical tasks", "weight": {"coding": 3, "no_code": 2}},
            {"text": "Not interested", "weight": {"support": 3}}
        ]
    },
    # Coding Orientation Questions
    {
        "id": "c1",
        "category": "coding",
        "question": "How do you feel about learning programming languages?",
        "options": [
            {"text": "Very excited to code", "weight": {"coding": 5}},
            {"text": "Interested but prefer visual tools", "weight": {"no_code": 4}},
            {"text": "Would rather avoid coding", "weight": {"content": 3, "support": 3}},
            {"text": "Only if absolutely necessary", "weight": {"design": 2, "no_code": 3}}
        ]
    },
    # No-Code Orientation Questions
    {
        "id": "nc1",
        "category": "no_code",
        "question": "How do you feel about using tools that don't require coding?",
        "options": [
            {"text": "Prefer using ready-made tools", "weight": {"no_code": 5}},
            {"text": "Like mixing tools with some code", "weight": {"coding": 2, "no_code": 3}},
            {"text": "Rather learn proper coding", "weight": {"coding": 4}},
            {"text": "Depends on the task", "weight": {"support": 2, "content": 2}}
        ]
    },
    # Content Creation Questions
    {
        "id": "cc1",
        "category": "content",
        "question": "How comfortable are you with writing and content creation?",
        "options": [
            {"text": "Love writing and creating content", "weight": {"content": 5}},
            {"text": "Enjoy it as part of other work", "weight": {"design": 2, "content": 3}},
            {"text": "Prefer technical tasks", "weight": {"coding": 3, "support": 2}},
            {"text": "Not my strength", "weight": {"no_code": 2, "support": 3}}
        ]
    }
]

# Career paths with required skills and descriptions
career_paths = {
    "design": {
        "roles": [
            "Graphic Designer",
            "UI/UX Designer",
            "Video Editor",
            "Presentation Designer",
            "Motion Graphics Animator"
        ],
        "skills": ["creativity", "visual design", "tool proficiency", "attention to detail"]
    },
    "coding": {
        "roles": [
            "Web Developer (Frontend)",
            "Web Developer (Backend)",
            "App Developer",
            "Game Developer",
            "WordPress Developer"
        ],
        "skills": ["programming", "problem-solving", "logical thinking", "technical skills"]
    },
    "no_code": {
        "roles": [
            "No-Code Web Developer",
            "Automation Specialist",
            "E-commerce Manager",
            "Email Marketing Specialist"
        ],
        "skills": ["tool mastery", "process optimization", "business logic", "automation"]
    },
    "content": {
        "roles": [
            "Social Media Manager",
            "SEO Specialist",
            "Content Writer",
            "Copywriter",
            "Affiliate Marketer"
        ],
        "skills": ["writing", "communication", "marketing", "creativity"]
    },
    "support": {
        "roles": [
            "Virtual Assistant",
            "Customer Support Specialist",
            "Data Entry Specialist",
            "Transcriptionist"
        ],
        "skills": ["organization", "communication", "attention to detail", "reliability"]
    }
}

def calculate_user_type(responses: List[Dict]) -> UserType:
    """
    Calculate the user type based on their responses to the initial questions.
    This will be integrated with Gemini API for more sophisticated analysis.
    """
    scores = {
        "newbie": 0,
        "beginner": 0,
        "career_switcher": 0,
        "experienced": 0
    }
    
    # Basic scoring implementation
    for response in responses:
        question_id = response.get("question_id")
        answer_index = response.get("answer_index")
        
        # Find the question
        question = next((q for q in user_type_questions if q["id"] == question_id), None)
        if question and 0 <= answer_index < len(question["options"]):
            weights = question["options"][answer_index]["weight"]
            for user_type, weight in weights.items():
                scores[user_type] += weight
    
    # Return the user type with highest score
    return UserType(max(scores.items(), key=lambda x: x[1])[0])

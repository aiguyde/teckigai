from sqlalchemy import Boolean, Column, ForeignKey, Integer, String, Float, Enum
from sqlalchemy.orm import relationship
from database import Base
import enum

class UserType(enum.Enum):
    NEWBIE = "newbie"
    BEGINNER = "beginner"
    CAREER_SWITCHER = "career_switcher"
    EXPERIENCED = "experienced"

class MembershipTier(enum.Enum):
    BASIC = "basic"
    PREMIUM = "premium"

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    full_name = Column(String)
    user_type = Column(String)
    membership_tier = Column(String, default=MembershipTier.BASIC.value)
    is_active = Column(Boolean, default=True)
    
    assessment_results = relationship("AssessmentResult", back_populates="user")
    learning_paths = relationship("LearningPath", back_populates="user")
    daily_tasks = relationship("DailyTask", back_populates="user")

class AssessmentResult(Base):
    __tablename__ = "assessment_results"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    career_path = Column(String)
    match_percentage = Column(Float)
    recommendations = Column(String)
    
    user = relationship("User", back_populates="assessment_results")

class LearningPath(Base):
    __tablename__ = "learning_paths"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    career_path = Column(String)
    progress = Column(Float, default=0.0)
    completed = Column(Boolean, default=False)
    
    user = relationship("User", back_populates="learning_paths")

class DailyTask(Base):
    __tablename__ = "daily_tasks"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    task_description = Column(String)
    completed = Column(Boolean, default=False)
    completion_date = Column(String)
    
    user = relationship("User", back_populates="daily_tasks")

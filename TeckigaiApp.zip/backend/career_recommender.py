import google.generativeai as genai
from typing import List, Dict
import os
from questions_pool import UserType, CareerCategory, career_paths

class CareerRecommender:
    def __init__(self):
        api_key = os.getenv('GEMINI_API_KEY')
        if not api_key:
            raise ValueError("GEMINI_API_KEY environment variable not set")
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-pro')

    def generate_career_recommendations(
        self,
        user_type: UserType,
        responses: List[Dict],
        career_interests: List[str]
    ) -> Dict:
        """
        Generate career recommendations using Gemini AI.
        """
        # Construct the prompt for Gemini
        prompt = self._construct_prompt(user_type, responses, career_interests)
        
        try:
            # Get response from Gemini
            response = self.model.generate_content(prompt)
            
            # Parse and structure the recommendations
            recommendations = self._parse_recommendations(response.text)
            
            return recommendations
        except Exception as e:
            print(f"Error generating recommendations: {str(e)}")
            return self._get_fallback_recommendations(user_type, responses)

    def _construct_prompt(
        self,
        user_type: UserType,
        responses: List[Dict],
        career_interests: List[str]
    ) -> str:
        """
        Construct a detailed prompt for Gemini AI.
        """
        prompt = f"""
        As a career guidance expert, analyze the following information and recommend the top 3 most suitable tech careers:

        User Profile:
        - Experience Level: {user_type.value}
        - Interests: {', '.join(career_interests)}

        Response Pattern:
        {self._format_responses(responses)}

        Available Career Paths:
        {self._format_career_paths()}

        Please provide:
        1. Top 3 recommended careers with percentage match
        2. Brief explanation for each recommendation
        3. Key skills to develop
        4. Estimated time to achieve basic proficiency

        Format the response as a structured JSON object.
        """
        return prompt

    def _format_responses(self, responses: List[Dict]) -> str:
        """Format user responses for the prompt."""
        formatted = []
        for resp in responses:
            formatted.append(f"Q: {resp.get('question')}\nA: {resp.get('answer')}")
        return "\n".join(formatted)

    def _format_career_paths(self) -> str:
        """Format available career paths for the prompt."""
        formatted = []
        for category, details in career_paths.items():
            roles = "\n".join(f"- {role}" for role in details["roles"])
            formatted.append(f"{category.upper()}:\n{roles}")
        return "\n\n".join(formatted)

    def _parse_recommendations(self, gemini_response: str) -> Dict:
        """Parse and structure Gemini's response."""
        # Implement parsing logic here
        # For now, return the raw response
        return {"recommendations": gemini_response}

    def _get_fallback_recommendations(
        self,
        user_type: UserType,
        responses: List[Dict]
    ) -> Dict:
        """
        Provide fallback recommendations if Gemini API fails.
        Uses the basic scoring system from questions_pool.
        """
        # Implement basic recommendation logic based on user_type and responses
        fallback_recommendations = {
            "status": "fallback",
            "recommendations": [
                {
                    "role": "Entry Level Position",
                    "match_percentage": 85,
                    "explanation": "Based on your profile as a " + user_type.value,
                    "required_skills": ["Basic technical skills", "Communication", "Willingness to learn"],
                    "estimated_time": "3-6 months"
                }
            ]
        }
        return fallback_recommendations

import React from 'react';
import { useTheme } from '../../context/ThemeContext';

const TermsOfService: React.FC = () => {
  const { theme } = useTheme();

  return (
    <div className={`min-h-screen ${
      theme === 'dark' ? 'bg-gray-900 text-white' : 'bg-white text-gray-900'
    }`}>
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-bold mb-8">Terms of Service</h1>
          
          <div className={`prose ${theme === 'dark' ? 'prose-invert' : ''} max-w-none`}>
            <h2>1. Introduction</h2>
            <p>
              Welcome to Teckigai ("we," "our," or "us"). By accessing or using our career assessment platform,
              you agree to be bound by these Terms of Service.
            </p>

            <h2>2. Service Description</h2>
            <p>
              Teckigai provides an AI-powered career assessment and recommendation platform designed to help
              individuals discover and navigate their ideal tech career paths.
            </p>

            <h2>3. User Accounts</h2>
            <p>
              To access certain features of our platform, you must register for an account. You agree to provide
              accurate and complete information during registration and to keep your account information updated.
            </p>

            <h2>4. User Responsibilities</h2>
            <ul>
              <li>Maintain the confidentiality of your account credentials</li>
              <li>Provide accurate information during assessments</li>
              <li>Use the platform in compliance with applicable laws</li>
              <li>Not share account access with third parties</li>
            </ul>

            <h2>5. Assessment Results</h2>
            <p>
              While we strive to provide accurate and helpful career recommendations, our assessments are meant
              to be guidance tools and should not be considered as definitive career advice. Users should
              conduct their own research and potentially seek professional career counseling.
            </p>

            <h2>6. Intellectual Property</h2>
            <p>
              All content, features, and functionality of the Teckigai platform, including but not limited to
              text, graphics, logos, and software, are owned by or licensed to us and are protected by
              intellectual property laws.
            </p>

            <h2>7. Privacy</h2>
            <p>
              Your privacy is important to us. Please review our Privacy Policy to understand how we collect,
              use, and protect your personal information.
            </p>

            <h2>8. Modifications to Service</h2>
            <p>
              We reserve the right to modify or discontinue the service at any time, with or without notice.
              We shall not be liable to you or any third party for any modification, suspension, or
              discontinuance of the service.
            </p>

            <h2>9. Limitation of Liability</h2>
            <p>
              To the maximum extent permitted by law, we shall not be liable for any indirect, incidental,
              special, consequential, or punitive damages arising out of or relating to your use of our service.
            </p>

            <h2>10. Contact Information</h2>
            <p>
              For questions about these Terms of Service, please contact us at:
              <br />
              Email: support@teckigai.com
              <br />
              Address: 123 Tech Street, Silicon Valley, CA 94025
            </p>

            <h2>11. Updates to Terms</h2>
            <p>
              We may update these Terms of Service from time to time. We will notify users of any material
              changes via email or through the platform. Your continued use of the service after such
              modifications constitutes your acceptance of the updated terms.
            </p>

            <p className="text-sm mt-8">Last updated: January 2024</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TermsOfService;

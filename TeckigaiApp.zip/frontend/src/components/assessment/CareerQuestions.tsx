import React, { useState } from 'react';
import { useTheme } from '../../context/ThemeContext';
import { Answer } from './AssessmentFlow';

interface CareerQuestionsProps {
  onAnswer: (answer: Answer) => void;
  answers: Answer[];
}

const questions = [
  {
    id: "d1",
    category: "design",
    question: "How do you feel about visual creativity and design?",
    options: [
      "Love creating visual content",
      "Enjoy it but not my strength",
      "Prefer technical tasks",
      "Not interested"
    ]
  },
  {
    id: "c1",
    category: "coding",
    question: "How do you feel about learning programming languages?",
    options: [
      "Very excited to code",
      "Interested but prefer visual tools",
      "Would rather avoid coding",
      "Only if absolutely necessary"
    ]
  },
  {
    id: "nc1",
    category: "no_code",
    question: "How do you feel about using tools that don't require coding?",
    options: [
      "Prefer using ready-made tools",
      "Like mixing tools with some code",
      "Rather learn proper coding",
      "Depends on the task"
    ]
  },
  {
    id: "cc1",
    category: "content",
    question: "How comfortable are you with writing and content creation?",
    options: [
      "Love writing and creating content",
      "Enjoy it as part of other work",
      "Prefer technical tasks",
      "Not my strength"
    ]
  }
];

const CareerQuestions: React.FC<CareerQuestionsProps> = ({ onAnswer, answers }) => {
  const { theme } = useTheme();
  const [currentQuestion, setCurrentQuestion] = useState(0);

  const handleOptionClick = (optionIndex: number) => {
    const answer: Answer = {
      questionId: questions[currentQuestion].id,
      answer: questions[currentQuestion].options[optionIndex],
      answerIndex: optionIndex
    };
    onAnswer(answer);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    }
  };

  const getCurrentAnswer = (questionId: string) => {
    return answers.find(a => a.questionId === questionId);
  };

  const question = questions[currentQuestion];
  const currentAnswer = getCurrentAnswer(question.id);

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-2xl font-bold mb-2">Let's find your ideal career path</h2>
        <p className={theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}>
          Step 2 of 2: Understanding your interests
        </p>
      </div>

      <div className="space-y-6">
        <h3 className="text-xl font-semibold">{question.question}</h3>
        <div className="space-y-3">
          {question.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleOptionClick(index)}
              className={`w-full p-4 rounded-lg text-left transition-all duration-200 ${
                currentAnswer?.answerIndex === index
                  ? theme === 'dark'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-blue-600 text-white'
                  : theme === 'dark'
                    ? 'bg-gray-800 hover:bg-gray-700 text-white'
                    : 'bg-gray-100 hover:bg-gray-200 text-gray-900'
              }`}
            >
              {option}
            </button>
          ))}
        </div>
      </div>

      <div className="flex justify-center">
        <div className="flex space-x-2">
          {questions.map((_, index) => (
            <div
              key={index}
              className={`w-2 h-2 rounded-full ${
                index === currentQuestion
                  ? theme === 'dark'
                    ? 'bg-indigo-600'
                    : 'bg-blue-600'
                  : theme === 'dark'
                    ? 'bg-gray-700'
                    : 'bg-gray-300'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default CareerQuestions;

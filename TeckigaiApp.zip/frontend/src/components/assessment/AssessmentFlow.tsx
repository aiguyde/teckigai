import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import UserTypeQuestions from './UserTypeQuestions';
import CareerQuestions from './CareerQuestions';
import ProgressBar from './ProgressBar';
import { useTheme } from '../../context/ThemeContext';

export type Answer = {
  questionId: string;
  answer: string;
  answerIndex: number;
};

const AssessmentFlow: React.FC = () => {
  const navigate = useNavigate();
  const { theme } = useTheme();
  const [step, setStep] = useState(1);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const totalSteps = 2;

  const handleAnswer = (answer: Answer) => {
    setAnswers(prev => {
      const filtered = prev.filter(a => a.questionId !== answer.questionId);
      return [...filtered, answer];
    });
  };

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(prev => prev + 1);
    } else {
      handleSubmit();
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(prev => prev - 1);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      // For now, we'll use mock data since the API isn't connected
      const mockResults = {
        userType: "beginner",
        topMatch: {
          category: "No-Code Development",
          score: 85,
          role: "No-Code Web Developer",
          skills: ["Tool mastery", "Process optimization", "Business logic", "Automation"],
          estimatedTime: "3-6 months"
        },
        hasMoreMatches: true
      };
      
      navigate('/results/preview', { 
        state: { 
          results: mockResults,
          answers // Save answers for later use after registration
        } 
      });
    } catch (error) {
      console.error('Error submitting assessment:', error);
      // Handle error appropriately
    } finally {
      setIsSubmitting(false);
    }
  };

  const getCurrentProgress = () => {
    return (step / totalSteps) * 100;
  };

  return (
    <div className={`min-h-screen ${
      theme === 'dark' 
        ? 'bg-gray-900 text-white' 
        : 'bg-white text-gray-900'
    }`}>
      <div className="container mx-auto px-4 py-8">
        <ProgressBar progress={getCurrentProgress()} />
        
        <div className="max-w-2xl mx-auto mt-8">
          {step === 1 && (
            <UserTypeQuestions
              onAnswer={handleAnswer}
              answers={answers}
            />
          )}
          
          {step === 2 && (
            <CareerQuestions
              onAnswer={handleAnswer}
              answers={answers}
            />
          )}
          
          <div className="flex justify-between mt-8">
            <button
              onClick={handleBack}
              disabled={step === 1}
              className={`px-6 py-2 rounded-lg ${
                step === 1
                  ? 'bg-gray-400 cursor-not-allowed'
                  : theme === 'dark'
                    ? 'bg-gray-700 hover:bg-gray-600'
                    : 'bg-gray-200 hover:bg-gray-300'
              }`}
            >
              Back
            </button>
            
            <button
              onClick={handleNext}
              disabled={isSubmitting}
              className={`px-6 py-2 rounded-lg ${
                theme === 'dark'
                  ? 'bg-indigo-600 hover:bg-indigo-700'
                  : 'bg-blue-600 hover:bg-blue-700'
              } text-white`}
            >
              {step === totalSteps ? (
                isSubmitting ? 'Submitting...' : 'Submit'
              ) : (
                'Next'
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AssessmentFlow;

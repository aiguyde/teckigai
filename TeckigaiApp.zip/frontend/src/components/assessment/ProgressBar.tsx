import React from 'react';
import { useTheme } from '../../context/ThemeContext';

interface ProgressBarProps {
  progress: number;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ progress }) => {
  const { theme } = useTheme();

  return (
    <div className={`w-full h-2 rounded-full ${
      theme === 'dark' ? 'bg-gray-700' : 'bg-gray-200'
    }`}>
      <div
        className={`h-full rounded-full transition-all duration-300 ${
          theme === 'dark'
            ? 'bg-gradient-to-r from-purple-600 to-indigo-600'
            : 'bg-gradient-to-r from-blue-500 to-indigo-500'
        }`}
        style={{ width: `${progress}%` }}
      />
    </div>
  );
};

export default ProgressBar;

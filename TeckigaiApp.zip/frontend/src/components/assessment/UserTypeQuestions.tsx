import React, { useState } from 'react';
import { useTheme } from '../../context/ThemeContext';
import { Answer } from './AssessmentFlow';

interface UserTypeQuestionsProps {
  onAnswer: (answer: Answer) => void;
  answers: Answer[];
}

const questions = [
  {
    id: "ut1",
    question: "What's your current experience level with online work?",
    options: [
      "No experience at all",
      "Some basic knowledge but no work experience",
      "Experienced in another field, new to tech",
      "Already working in tech/online"
    ]
  },
  {
    id: "ut2",
    question: "What's your primary motivation for pursuing an online career?",
    options: [
      "Exploring new opportunities",
      "Building basic skills",
      "Career transition",
      "Skill enhancement"
    ]
  },
  {
    id: "ut3",
    question: "How much time can you dedicate to learning?",
    options: [
      "Just starting to explore (1-2 hours/week)",
      "Part-time (5-10 hours/week)",
      "Full-time dedication",
      "Already working, looking to upskill"
    ]
  }
];

const UserTypeQuestions: React.FC<UserTypeQuestionsProps> = ({ onAnswer, answers }) => {
  const { theme } = useTheme();
  const [currentQuestion, setCurrentQuestion] = useState(0);

  const handleOptionClick = (optionIndex: number) => {
    const answer: Answer = {
      questionId: questions[currentQuestion].id,
      answer: questions[currentQuestion].options[optionIndex],
      answerIndex: optionIndex
    };
    onAnswer(answer);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    }
  };

  const getCurrentAnswer = (questionId: string) => {
    return answers.find(a => a.questionId === questionId);
  };

  const question = questions[currentQuestion];
  const currentAnswer = getCurrentAnswer(question.id);

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-2xl font-bold mb-2">Let's get to know you better</h2>
        <p className={theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}>
          Step 1 of 2: Understanding your background
        </p>
      </div>

      <div className="space-y-6">
        <h3 className="text-xl font-semibold">{question.question}</h3>
        <div className="space-y-3">
          {question.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleOptionClick(index)}
              className={`w-full p-4 rounded-lg text-left transition-all duration-200 ${
                currentAnswer?.answerIndex === index
                  ? theme === 'dark'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-blue-600 text-white'
                  : theme === 'dark'
                    ? 'bg-gray-800 hover:bg-gray-700 text-white'
                    : 'bg-gray-100 hover:bg-gray-200 text-gray-900'
              }`}
            >
              {option}
            </button>
          ))}
        </div>
      </div>

      <div className="flex justify-center">
        <div className="flex space-x-2">
          {questions.map((_, index) => (
            <div
              key={index}
              className={`w-2 h-2 rounded-full ${
                index === currentQuestion
                  ? theme === 'dark'
                    ? 'bg-indigo-600'
                    : 'bg-blue-600'
                  : theme === 'dark'
                    ? 'bg-gray-700'
                    : 'bg-gray-300'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default UserTypeQuestions;

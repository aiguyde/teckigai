import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTheme } from '../../context/ThemeContext';

interface UserProfile {
  name: string;
  email: string;
  avatar?: string;
  bio?: string;
  location?: string;
  socialLinks?: {
    linkedin?: string;
    github?: string;
    twitter?: string;
  };
  skills?: string[];
  interests?: string[];
  careerGoals?: string[];
  learningStreak?: number;
  completedCourses?: number;
  joinedDate?: string;
}

const ProfilePage: React.FC = () => {
  const { theme } = useTheme();
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  const [profile, setProfile] = useState<UserProfile>({
    name: '',
    email: '',
    bio: '',
    location: '',
    socialLinks: {},
    skills: [],
    interests: [],
    careerGoals: [],
    learningStreak: 0,
    completedCourses: 0,
    joinedDate: new Date().toISOString(),
  });

  useEffect(() => {
    // Load user data from localStorage
    const userData = localStorage.getItem('user');
    if (userData) {
      const parsedData = JSON.parse(userData);
      setProfile(prev => ({
        ...prev,
        ...parsedData,
      }));
    } else {
      navigate('/login');
    }
  }, [navigate]);

  const handleSave = () => {
    localStorage.setItem('user', JSON.stringify(profile));
    setIsEditing(false);
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
    field: keyof UserProfile
  ) => {
    setProfile(prev => ({
      ...prev,
      [field]: e.target.value,
    }));
  };

  const handleArrayInputChange = (
    e: React.KeyboardEvent<HTMLInputElement>,
    field: 'skills' | 'interests' | 'careerGoals',
    inputRef: React.RefObject<HTMLInputElement>
  ) => {
    if (e.key === 'Enter' && inputRef.current?.value) {
      setProfile(prev => ({
        ...prev,
        [field]: [...(prev[field] || []), inputRef.current!.value],
      }));
      inputRef.current.value = '';
    }
  };

  const removeArrayItem = (
    field: 'skills' | 'interests' | 'careerGoals',
    index: number
  ) => {
    setProfile(prev => ({
      ...prev,
      [field]: prev[field]?.filter((_, i) => i !== index),
    }));
  };

  return (
    <div className={`min-h-screen ${
      theme === 'dark' ? 'bg-gray-900 text-white' : 'bg-white text-gray-900'
    }`}>
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Profile Header */}
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">Profile</h1>
          <button
            onClick={() => isEditing ? handleSave() : setIsEditing(true)}
            className={`px-4 py-2 rounded-lg ${
              theme === 'dark'
                ? 'bg-blue-600 hover:bg-blue-700'
                : 'bg-blue-500 hover:bg-blue-600'
            } text-white`}
          >
            {isEditing ? 'Save Changes' : 'Edit Profile'}
          </button>
        </div>

        {/* Profile Content */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Left Column - Basic Info */}
          <div className="space-y-6">
            {/* Avatar */}
            <div className={`p-6 rounded-xl ${
              theme === 'dark' ? 'bg-gray-800' : 'bg-gray-50'
            }`}>
              <div className="flex flex-col items-center">
                <div className={`w-32 h-32 rounded-full flex items-center justify-center text-4xl ${
                  theme === 'dark' ? 'bg-gray-700' : 'bg-gray-200'
                }`}>
                  {profile.avatar || profile.name?.[0]?.toUpperCase() || '👤'}
                </div>
                {isEditing && (
                  <button className="mt-4 text-blue-500 hover:text-blue-400">
                    Change Avatar
                  </button>
                )}
              </div>
            </div>

            {/* Basic Info */}
            <div className={`p-6 rounded-xl ${
              theme === 'dark' ? 'bg-gray-800' : 'bg-gray-50'
            }`}>
              <h2 className="text-xl font-semibold mb-4">Basic Information</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Name</label>
                  {isEditing ? (
                    <input
                      type="text"
                      value={profile.name}
                      onChange={(e) => handleInputChange(e, 'name')}
                      className={`w-full px-3 py-2 rounded-lg ${
                        theme === 'dark'
                          ? 'bg-gray-700 border-gray-600'
                          : 'bg-white border-gray-300'
                      } border`}
                    />
                  ) : (
                    <p>{profile.name}</p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Email</label>
                  <p>{profile.email}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Location</label>
                  {isEditing ? (
                    <input
                      type="text"
                      value={profile.location}
                      onChange={(e) => handleInputChange(e, 'location')}
                      className={`w-full px-3 py-2 rounded-lg ${
                        theme === 'dark'
                          ? 'bg-gray-700 border-gray-600'
                          : 'bg-white border-gray-300'
                      } border`}
                    />
                  ) : (
                    <p>{profile.location || 'Not specified'}</p>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Middle Column - Career & Skills */}
          <div className="space-y-6">
            {/* Bio */}
            <div className={`p-6 rounded-xl ${
              theme === 'dark' ? 'bg-gray-800' : 'bg-gray-50'
            }`}>
              <h2 className="text-xl font-semibold mb-4">About Me</h2>
              {isEditing ? (
                <textarea
                  value={profile.bio}
                  onChange={(e) => handleInputChange(e, 'bio')}
                  className={`w-full px-3 py-2 rounded-lg ${
                    theme === 'dark'
                      ? 'bg-gray-700 border-gray-600'
                      : 'bg-white border-gray-300'
                  } border`}
                  rows={4}
                />
              ) : (
                <p>{profile.bio || 'No bio provided'}</p>
              )}
            </div>

            {/* Skills */}
            <div className={`p-6 rounded-xl ${
              theme === 'dark' ? 'bg-gray-800' : 'bg-gray-50'
            }`}>
              <h2 className="text-xl font-semibold mb-4">Skills</h2>
              <div className="flex flex-wrap gap-2">
                {profile.skills?.map((skill, index) => (
                  <span
                    key={index}
                    className={`px-3 py-1 rounded-full text-sm ${
                      theme === 'dark'
                        ? 'bg-gray-700 text-gray-300'
                        : 'bg-gray-200 text-gray-700'
                    }`}
                  >
                    {skill}
                    {isEditing && (
                      <button
                        onClick={() => removeArrayItem('skills', index)}
                        className="ml-2 text-red-500 hover:text-red-400"
                      >
                        ×
                      </button>
                    )}
                  </span>
                ))}
              </div>
              {isEditing && (
                <input
                  type="text"
                  placeholder="Add a skill (press Enter)"
                  className={`mt-4 w-full px-3 py-2 rounded-lg ${
                    theme === 'dark'
                      ? 'bg-gray-700 border-gray-600'
                      : 'bg-white border-gray-300'
                  } border`}
                  onKeyDown={(e) => handleArrayInputChange(e, 'skills', { current: e.currentTarget })}
                />
              )}
            </div>
          </div>

          {/* Right Column - Stats & Social */}
          <div className="space-y-6">
            {/* Stats */}
            <div className={`p-6 rounded-xl ${
              theme === 'dark' ? 'bg-gray-800' : 'bg-gray-50'
            }`}>
              <h2 className="text-xl font-semibold mb-4">Statistics</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Learning Streak</label>
                  <p className="text-2xl font-bold">
                    {profile.learningStreak} days
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Completed Courses</label>
                  <p className="text-2xl font-bold">
                    {profile.completedCourses}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Member Since</label>
                  <p>
                    {new Date(profile.joinedDate || '').toLocaleDateString()}
                  </p>
                </div>
              </div>
            </div>

            {/* Social Links */}
            <div className={`p-6 rounded-xl ${
              theme === 'dark' ? 'bg-gray-800' : 'bg-gray-50'
            }`}>
              <h2 className="text-xl font-semibold mb-4">Social Links</h2>
              <div className="space-y-4">
                {isEditing ? (
                  <>
                    <div>
                      <label className="block text-sm font-medium mb-1">LinkedIn</label>
                      <input
                        type="text"
                        value={profile.socialLinks?.linkedin || ''}
                        onChange={(e) => setProfile(prev => ({
                          ...prev,
                          socialLinks: {
                            ...prev.socialLinks,
                            linkedin: e.target.value,
                          },
                        }))}
                        className={`w-full px-3 py-2 rounded-lg ${
                          theme === 'dark'
                            ? 'bg-gray-700 border-gray-600'
                            : 'bg-white border-gray-300'
                        } border`}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">GitHub</label>
                      <input
                        type="text"
                        value={profile.socialLinks?.github || ''}
                        onChange={(e) => setProfile(prev => ({
                          ...prev,
                          socialLinks: {
                            ...prev.socialLinks,
                            github: e.target.value,
                          },
                        }))}
                        className={`w-full px-3 py-2 rounded-lg ${
                          theme === 'dark'
                            ? 'bg-gray-700 border-gray-600'
                            : 'bg-white border-gray-300'
                        } border`}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Twitter</label>
                      <input
                        type="text"
                        value={profile.socialLinks?.twitter || ''}
                        onChange={(e) => setProfile(prev => ({
                          ...prev,
                          socialLinks: {
                            ...prev.socialLinks,
                            twitter: e.target.value,
                          },
                        }))}
                        className={`w-full px-3 py-2 rounded-lg ${
                          theme === 'dark'
                            ? 'bg-gray-700 border-gray-600'
                            : 'bg-white border-gray-300'
                        } border`}
                      />
                    </div>
                  </>
                ) : (
                  <div className="space-y-2">
                    {profile.socialLinks?.linkedin && (
                      <a
                        href={profile.socialLinks.linkedin}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-500 hover:text-blue-400 block"
                      >
                        LinkedIn
                      </a>
                    )}
                    {profile.socialLinks?.github && (
                      <a
                        href={profile.socialLinks.github}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-500 hover:text-blue-400 block"
                      >
                        GitHub
                      </a>
                    )}
                    {profile.socialLinks?.twitter && (
                      <a
                        href={profile.socialLinks.twitter}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-500 hover:text-blue-400 block"
                      >
                        Twitter
                      </a>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;

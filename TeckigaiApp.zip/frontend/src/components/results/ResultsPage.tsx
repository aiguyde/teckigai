import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useTheme } from '../../context/ThemeContext';

interface CareerResult {
  category: string;
  score: number;
  roles: string[];
  skills: string[];
  estimatedTime: string;
}

interface AssessmentResult {
  userType: string;
  topCareers: CareerResult[];
  personalityTraits?: {
    [key: string]: number;
  };
}

const ResultsPage: React.FC = () => {
  const { theme } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();
  const [selectedCareer, setSelectedCareer] = useState<number>(0);

  // Get results from location state or use sample data for development
  const results: AssessmentResult = location.state?.results || {
    userType: "beginner",
    topCareers: [
      {
        category: "No-Code Development",
        score: 85,
        roles: ["No-Code Web Developer", "Automation Specialist", "E-commerce Manager"],
        skills: ["Tool mastery", "Process optimization", "Business logic", "Automation"],
        estimatedTime: "3-6 months"
      },
      {
        category: "Content Creation",
        score: 78,
        roles: ["Content Writer", "Social Media Manager", "SEO Specialist"],
        skills: ["Writing", "Communication", "Marketing", "Creativity"],
        estimatedTime: "2-4 months"
      },
      {
        category: "Design",
        score: 72,
        roles: ["UI/UX Designer", "Graphic Designer", "Presentation Designer"],
        skills: ["Visual design", "User experience", "Creative tools", "Typography"],
        estimatedTime: "4-8 months"
      }
    ]
  };

  const getEmoji = (category: string): string => {
    const emojiMap: { [key: string]: string } = {
      "No-Code Development": "🛠️",
      "Content Creation": "✍️",
      "Design": "🎨",
      "Coding": "💻",
      "Support": "🤝"
    };
    return emojiMap[category] || "🎯";
  };

  const getGradientColor = (index: number): string => {
    const gradients = [
      'from-purple-600 to-indigo-600',
      'from-blue-600 to-cyan-600',
      'from-emerald-600 to-teal-600'
    ];
    return gradients[index] || gradients[0];
  };

  return (
    <div className={`min-h-screen ${
      theme === 'dark' 
        ? 'bg-gray-900 text-white' 
        : 'bg-white text-gray-900'
    }`}>
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Your Perfect Tech Career Match</h1>
          <p className={`text-xl ${
            theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
          }`}>
            Based on your profile as a {results.userType}, here are your top matches
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {results.topCareers.map((career, index) => (
            <div
              key={index}
              onClick={() => setSelectedCareer(index)}
              className={`${
                theme === 'dark' 
                  ? 'bg-gray-800 hover:bg-gray-700' 
                  : 'bg-white hover:bg-gray-50'
              } rounded-xl p-6 shadow-lg cursor-pointer transition-all duration-300 transform hover:-translate-y-1 ${
                selectedCareer === index ? 'ring-2 ring-offset-2 ring-indigo-500' : ''
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-3xl">{getEmoji(career.category)}</span>
                <span className={`text-2xl font-bold ${
                  theme === 'dark' ? 'text-indigo-400' : 'text-indigo-600'
                }`}>{Math.round(career.score)}%</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">{career.category}</h3>
              <div className={`h-2 rounded-full bg-gradient-to-r ${getGradientColor(index)} mt-2 mb-4`}
                style={{ width: `${career.score}%` }}
              />
              <p className={`${
                theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
              }`}>
                Top role: {career.roles[0]}
              </p>
            </div>
          ))}
        </div>

        {/* Detailed Career View */}
        <div className={`${
          theme === 'dark' ? 'bg-gray-800' : 'bg-white'
        } rounded-xl p-8 shadow-lg mb-8`}>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h2 className="text-2xl font-bold mb-4">
                {getEmoji(results.topCareers[selectedCareer].category)}{' '}
                {results.topCareers[selectedCareer].category}
              </h2>
              
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-semibold mb-3">Recommended Roles</h3>
                  <ul className="space-y-2">
                    {results.topCareers[selectedCareer].roles.map((role, index) => (
                      <li key={index} className="flex items-center">
                        <span className={`w-2 h-2 rounded-full ${
                          theme === 'dark' ? 'bg-indigo-500' : 'bg-indigo-600'
                        } mr-3`}/>
                        {role}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h3 className="text-xl font-semibold mb-3">Required Skills</h3>
                  <div className="flex flex-wrap gap-2">
                    {results.topCareers[selectedCareer].skills.map((skill, index) => (
                      <span
                        key={index}
                        className={`px-3 py-1 rounded-full text-sm ${
                          theme === 'dark'
                            ? 'bg-gray-700 text-gray-300'
                            : 'bg-gray-100 text-gray-700'
                        }`}
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div>
              <div className={`${
                theme === 'dark' ? 'bg-gray-700' : 'bg-gray-50'
              } rounded-xl p-6`}>
                <h3 className="text-xl font-semibold mb-4">Getting Started</h3>
                <div className="space-y-4">
                  <p>
                    Estimated time to basic proficiency:{' '}
                    <span className="font-semibold">
                      {results.topCareers[selectedCareer].estimatedTime}
                    </span>
                  </p>
                  <button
                    onClick={() => navigate('/learning-path')}
                    className={`w-full py-3 px-6 rounded-lg ${
                      theme === 'dark'
                        ? 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700'
                        : 'bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600'
                    } text-white font-semibold transition-all duration-200`}
                  >
                    View Learning Path
                  </button>
                  <button
                    onClick={() => navigate('/community')}
                    className={`w-full py-3 px-6 rounded-lg ${
                      theme === 'dark'
                        ? 'bg-gray-600 hover:bg-gray-500'
                        : 'bg-gray-200 hover:bg-gray-300'
                    } font-semibold transition-all duration-200`}
                  >
                    Join Community
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-center space-x-4">
          <button
            onClick={() => navigate('/assessment')}
            className={`px-6 py-2 rounded-lg ${
              theme === 'dark'
                ? 'bg-gray-700 hover:bg-gray-600'
                : 'bg-gray-200 hover:bg-gray-300'
            }`}
          >
            Retake Assessment
          </button>
          <button
            onClick={() => window.print()}
            className={`px-6 py-2 rounded-lg ${
              theme === 'dark'
                ? 'bg-gray-700 hover:bg-gray-600'
                : 'bg-gray-200 hover:bg-gray-300'
            }`}
          >
            Save Results
          </button>
        </div>
      </div>
    </div>
  );
};

export default ResultsPage;

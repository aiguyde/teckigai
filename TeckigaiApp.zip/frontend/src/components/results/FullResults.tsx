import React, { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useTheme } from '../../context/ThemeContext';

interface CareerResult {
  category: string;
  score: number;
  roles: string[];
  skills: string[];
  estimatedTime: string;
}

interface AssessmentResult {
  userType: string;
  topCareers: CareerResult[];
}

const FullResults: React.FC = () => {
  const { theme } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();
  const [selectedCareer, setSelectedCareer] = React.useState<number>(0);

  // Check if user is authenticated
  useEffect(() => {
    const isAuthenticated = localStorage.getItem('isAuthenticated'); // Replace with your auth check
    if (!isAuthenticated) {
      navigate('/register');
    }
  }, [navigate]);

  // Get results from location state or use sample data for development
  const results: AssessmentResult = location.state?.results || {
    userType: "beginner",
    topCareers: [
      {
        category: "No-Code Development",
        score: 85,
        roles: ["No-Code Web Developer", "Automation Specialist", "E-commerce Manager"],
        skills: ["Tool mastery", "Process optimization", "Business logic", "Automation"],
        estimatedTime: "3-6 months"
      },
      {
        category: "Content Creation",
        score: 78,
        roles: ["Content Writer", "Social Media Manager", "SEO Specialist"],
        skills: ["Writing", "Communication", "Marketing", "Creativity"],
        estimatedTime: "2-4 months"
      },
      {
        category: "Design",
        score: 72,
        roles: ["UI/UX Designer", "Graphic Designer", "Presentation Designer"],
        skills: ["Visual design", "User experience", "Creative tools", "Typography"],
        estimatedTime: "4-8 months"
      }
    ]
  };

  const getEmoji = (category: string): string => {
    const emojiMap: { [key: string]: string } = {
      "No-Code Development": "🛠️",
      "Content Creation": "✍️",
      "Design": "🎨",
      "Coding": "💻",
      "Support": "🤝"
    };
    return emojiMap[category] || "🎯";
  };

  const getGradientColor = (index: number): string => {
    const gradients = [
      'from-purple-600 to-indigo-600',
      'from-blue-600 to-cyan-600',
      'from-emerald-600 to-teal-600'
    ];
    return gradients[index] || gradients[0];
  };

  const handleCareerSelect = (index: number) => {
    setSelectedCareer(index);
    navigate('/dashboard', { 
      state: { 
        selectedCareer: results.topCareers[index],
        allCareers: results.topCareers
      }
    });
  };

  return (
    <div className={`min-h-screen ${
      theme === 'dark' 
        ? 'bg-gray-900 text-white' 
        : 'bg-white text-gray-900'
    }`}>
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Your Complete Career Matches</h1>
          <p className={`text-xl ${
            theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
          }`}>
            Click on any career to view your personalized learning path
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {results.topCareers.map((career, index) => (
            <div
              key={index}
              onClick={() => handleCareerSelect(index)}
              className={`${
                theme === 'dark' 
                  ? 'bg-gray-800 hover:bg-gray-700' 
                  : 'bg-white hover:bg-gray-50'
              } rounded-xl p-6 shadow-lg cursor-pointer transition-all duration-300 
              transform hover:-translate-y-1 hover:shadow-xl`}
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-3xl">{getEmoji(career.category)}</span>
                <span className={`text-2xl font-bold ${
                  theme === 'dark' ? 'text-indigo-400' : 'text-indigo-600'
                }`}>{Math.round(career.score)}%</span>
              </div>
              
              <h3 className="text-xl font-semibold mb-2">{career.category}</h3>
              <div className={`h-2 rounded-full bg-gradient-to-r ${getGradientColor(index)} mt-2 mb-4`}
                style={{ width: `${career.score}%` }}
              />

              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Top Roles:</h4>
                  <ul className="space-y-1">
                    {career.roles.slice(0, 2).map((role, idx) => (
                      <li key={idx} className={`${
                        theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
                      }`}>
                        • {role}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <p className={`${
                    theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
                  }`}>
                    Time to proficiency: {career.estimatedTime}
                  </p>
                </div>
              </div>

              <button
                className={`w-full mt-4 py-2 px-4 rounded-lg ${
                  theme === 'dark'
                    ? 'bg-gray-700 hover:bg-gray-600'
                    : 'bg-gray-100 hover:bg-gray-200'
                } transition-colors duration-200`}
              >
                Begin Your Journey 🚀
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FullResults;

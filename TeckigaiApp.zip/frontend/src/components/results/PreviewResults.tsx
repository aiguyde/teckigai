import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useTheme } from '../../context/ThemeContext';

interface TopMatch {
  category: string;
  score: number;
  role: string;
  skills: string[];
  estimatedTime: string;
}

interface PreviewResult {
  userType: string;
  topMatch: TopMatch;
  hasMoreMatches: boolean;
}

const PreviewResults: React.FC = () => {
  const { theme } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();
  const [showRegisterModal, setShowRegisterModal] = useState(false);

  const results: PreviewResult = location.state?.results || {
    userType: "beginner",
    topMatch: {
      category: "No-Code Development",
      score: 85,
      role: "No-Code Web Developer",
      skills: ["Tool mastery", "Process optimization", "Business logic", "Automation"],
      estimatedTime: "3-6 months"
    },
    hasMoreMatches: true
  };

  const getEmoji = (category: string): string => {
    const emojiMap: { [key: string]: string } = {
      "No-Code Development": "🛠️",
      "Content Creation": "✍️",
      "Design": "🎨",
      "Coding": "💻",
      "Support": "🤝"
    };
    return emojiMap[category] || "🎯";
  };

  const handleRegisterClick = () => {
    // Save assessment data to localStorage for use after registration
    if (location.state?.answers) {
      localStorage.setItem('assessmentAnswers', JSON.stringify(location.state.answers));
    }
    navigate('/register');
  };

  return (
    <div className={`min-h-screen ${
      theme === 'dark' 
        ? 'bg-gray-900 text-white' 
        : 'bg-white text-gray-900'
    }`}>
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">We Found Your Perfect Match!</h1>
          <p className={`text-xl ${
            theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
          }`}>
            Based on your profile as a {results.userType}, here's your top career match
          </p>
        </div>

        {/* Top Match Card */}
        <div className="max-w-2xl mx-auto mb-12">
          <div className={`${
            theme === 'dark' 
              ? 'bg-gray-800' 
              : 'bg-white'
          } rounded-xl p-8 shadow-lg`}>
            <div className="flex items-center justify-between mb-6">
              <span className="text-4xl">{getEmoji(results.topMatch.category)}</span>
              <div className={`text-3xl font-bold ${
                theme === 'dark' ? 'text-indigo-400' : 'text-indigo-600'
              }`}>
                {results.topMatch.score}% Match
              </div>
            </div>

            <h2 className="text-2xl font-bold mb-4">{results.topMatch.category}</h2>
            <div className={`h-2 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 mb-6`}
              style={{ width: `${results.topMatch.score}%` }}
            />

            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-semibold mb-3">Recommended Role</h3>
                <p className={`text-lg ${
                  theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
                }`}>
                  {results.topMatch.role}
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3">Key Skills</h3>
                <div className="flex flex-wrap gap-2">
                  {results.topMatch.skills.map((skill, index) => (
                    <span
                      key={index}
                      className={`px-3 py-1 rounded-full text-sm ${
                        theme === 'dark'
                          ? 'bg-gray-700 text-gray-300'
                          : 'bg-gray-100 text-gray-700'
                      }`}
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3">Time to Proficiency</h3>
                <p className={`${
                  theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
                }`}>
                  {results.topMatch.estimatedTime}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Teaser Section */}
        <div className="max-w-2xl mx-auto text-center space-y-8">
          <div className={`${
            theme === 'dark' ? 'bg-gray-800' : 'bg-gray-50'
          } rounded-xl p-8`}>
            <h3 className="text-2xl font-bold mb-4">
              🎉 We Found Two More Great Matches for You!
            </h3>
            <p className={`text-lg mb-6 ${
              theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
            }`}>
              Register now to unlock your full career potential and discover all your matches.
              Plus, get access to:
            </p>
            <ul className="space-y-3 text-left mb-8">
              <li className="flex items-center">
                <span className="mr-2">✨</span>
                Detailed learning paths for each career
              </li>
              <li className="flex items-center">
                <span className="mr-2">🤝</span>
                Connect with mentors in your chosen field
              </li>
              <li className="flex items-center">
                <span className="mr-2">📈</span>
                Track your progress and set goals
              </li>
            </ul>
            
            <button
              onClick={handleRegisterClick}
              className={`w-full py-4 px-8 rounded-lg ${
                theme === 'dark'
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700'
                  : 'bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600'
              } text-white text-lg font-semibold transition-all duration-200`}
            >
              Register Now to See All Matches
            </button>
          </div>

          <button
            onClick={() => navigate('/assessment')}
            className={`px-6 py-2 rounded-lg ${
              theme === 'dark'
                ? 'bg-gray-700 hover:bg-gray-600'
                : 'bg-gray-200 hover:bg-gray-300'
            }`}
          >
            Retake Assessment
          </button>
        </div>
      </div>
    </div>
  );
};

export default PreviewResults;

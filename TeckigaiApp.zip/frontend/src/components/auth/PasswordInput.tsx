import React, { useState, useEffect } from 'react';
import { useTheme } from '../../context/ThemeContext';

interface PasswordStrength {
  score: number;
  feedback: string;
  color: string;
}

interface PasswordInputProps {
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  name: string;
  placeholder?: string;
  showStrength?: boolean;
}

const PasswordInput: React.FC<PasswordInputProps> = ({
  value,
  onChange,
  name,
  placeholder = "Enter your password",
  showStrength = true
}) => {
  const { theme } = useTheme();
  const [strength, setStrength] = useState<PasswordStrength>({
    score: 0,
    feedback: '',
    color: 'bg-gray-300'
  });
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    if (!showStrength) return;
    
    const calculateStrength = (password: string): PasswordStrength => {
      let score = 0;
      let feedback = '';

      // Length check
      if (password.length >= 12) score += 2;
      else if (password.length >= 8) score += 1;

      // Character variety checks
      if (/[A-Z]/.test(password)) score += 1;
      if (/[a-z]/.test(password)) score += 1;
      if (/[0-9]/.test(password)) score += 1;
      if (/[^A-Za-z0-9]/.test(password)) score += 1;

      // Sequence and repetition checks
      if (/(123|234|345|456|567|678|789|987|876|765|654|543|432|321)/.test(password)) score -= 1;
      if (/(.)\1{2,}/.test(password)) score -= 1;

      // Normalize score
      score = Math.max(0, Math.min(5, score));

      // Determine feedback and color
      switch (score) {
        case 0:
          feedback = 'Very weak';
          return { score, feedback, color: 'bg-red-500' };
        case 1:
          feedback = 'Weak';
          return { score, feedback, color: 'bg-orange-500' };
        case 2:
          feedback = 'Fair';
          return { score, feedback, color: 'bg-yellow-500' };
        case 3:
          feedback = 'Good';
          return { score, feedback, color: 'bg-blue-500' };
        case 4:
          feedback = 'Strong';
          return { score, feedback, color: 'bg-green-500' };
        case 5:
          feedback = 'Very strong';
          return { score, feedback, color: 'bg-emerald-500' };
        default:
          return { score: 0, feedback: '', color: 'bg-gray-300' };
      }
    };

    setStrength(calculateStrength(value));
  }, [value, showStrength]);

  return (
    <div className="space-y-2">
      <div className="relative">
        <input
          type={showPassword ? 'text' : 'password'}
          name={name}
          value={value}
          onChange={onChange}
          className={`w-full px-4 py-2 rounded-lg border ${
            theme === 'dark'
              ? 'bg-gray-700 border-gray-600 text-white'
              : 'bg-white border-gray-300'
          } focus:outline-none focus:ring-2 focus:ring-indigo-500 pr-10`}
          placeholder={placeholder}
        />
        <button
          type="button"
          onClick={() => setShowPassword(!showPassword)}
          className={`absolute right-3 top-1/2 transform -translate-y-1/2 ${
            theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
          } hover:text-indigo-500 focus:outline-none`}
        >
          {showPassword ? (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
            </svg>
          ) : (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
            </svg>
          )}
        </button>
      </div>

      {showStrength && value && (
        <div className="space-y-1">
          <div className="flex h-1 overflow-hidden rounded-full bg-gray-200">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className={`flex-1 ${
                  i < strength.score ? strength.color : 'bg-gray-200'
                } ${i > 0 ? 'ml-0.5' : ''}`}
              />
            ))}
          </div>
          <p className={`text-sm ${
            theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
          }`}>
            Password strength: {strength.feedback}
          </p>
        </div>
      )}
    </div>
  );
};

export default PasswordInput;

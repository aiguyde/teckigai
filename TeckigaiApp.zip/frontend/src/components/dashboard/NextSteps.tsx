import React from 'react';
import { useTheme } from '../../context/ThemeContext';

interface CareerPath {
  category: string;
  roles: string[];
  skills: string[];
  estimatedTime: string;
}

interface NextStepsProps {
  career: CareerPath;
}

const NextSteps: React.FC<NextStepsProps> = ({ career }) => {
  const { theme } = useTheme();

  // Mock next steps data (replace with real data from backend)
  const nextSteps = [
    {
      title: "Complete Introduction to No-Code Tools",
      type: "lesson",
      duration: "30 mins",
      status: "in_progress"
    },
    {
      title: "Build Your First Automation",
      type: "project",
      duration: "1 hour",
      status: "upcoming"
    },
    {
      title: "Tool Mastery Quiz",
      type: "quiz",
      duration: "15 mins",
      status: "upcoming"
    },
    {
      title: "Join Community Discussion",
      type: "community",
      duration: "flexible",
      status: "upcoming"
    }
  ];

  const getStepIcon = (type: string) => {
    switch (type) {
      case 'lesson':
        return '📚';
      case 'project':
        return '🛠️';
      case 'quiz':
        return '✍️';
      case 'community':
        return '👥';
      default:
        return '📌';
    }
  };

  return (
    <div className={`${
      theme === 'dark' ? 'bg-gray-700' : 'bg-gray-50'
    } rounded-xl p-6`}>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold">Next Steps</h2>
        <button className={`px-4 py-2 rounded-lg ${
          theme === 'dark'
            ? 'bg-gray-600 hover:bg-gray-500'
            : 'bg-white hover:bg-gray-100'
        } transition-colors duration-200`}>
          View All
        </button>
      </div>

      <div className="space-y-4">
        {nextSteps.map((step, index) => (
          <div
            key={index}
            className={`${
              theme === 'dark' ? 'bg-gray-800' : 'bg-white'
            } rounded-lg p-4 transition-transform duration-200 transform hover:-translate-y-1 cursor-pointer`}
          >
            <div className="flex items-start gap-4">
              {/* Step Icon */}
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                theme === 'dark' ? 'bg-gray-700' : 'bg-gray-100'
              }`}>
                <span className="text-xl">{getStepIcon(step.type)}</span>
              </div>

              {/* Step Content */}
              <div className="flex-grow">
                <h3 className="font-semibold mb-1">{step.title}</h3>
                <div className="flex items-center gap-4">
                  <span className={`text-sm ${
                    theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
                  }`}>
                    {step.duration}
                  </span>
                  <span className={`text-sm px-2 py-1 rounded-full ${
                    step.status === 'in_progress'
                      ? theme === 'dark'
                        ? 'bg-blue-900 text-blue-200'
                        : 'bg-blue-100 text-blue-800'
                      : theme === 'dark'
                        ? 'bg-gray-600 text-gray-300'
                        : 'bg-gray-100 text-gray-600'
                  }`}>
                    {step.status === 'in_progress' ? 'In Progress' : 'Up Next'}
                  </span>
                </div>
              </div>

              {/* Action Button */}
              <button className={`ml-4 p-2 rounded-lg ${
                theme === 'dark'
                  ? 'bg-gray-700 hover:bg-gray-600'
                  : 'bg-gray-100 hover:bg-gray-200'
              } transition-colors duration-200`}>
                {step.status === 'in_progress' ? 'Continue' : 'Start'}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Daily Goal Progress */}
      <div className={`mt-6 p-4 rounded-lg ${
        theme === 'dark' ? 'bg-gray-800' : 'bg-white'
      }`}>
        <div className="flex justify-between items-center mb-2">
          <span className="font-semibold">Daily Goal</span>
          <span className={theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}>
            1/2 hours
          </span>
        </div>
        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-green-500 to-emerald-500"
            style={{ width: '50%' }}
          />
        </div>
      </div>
    </div>
  );
};

export default NextSteps;

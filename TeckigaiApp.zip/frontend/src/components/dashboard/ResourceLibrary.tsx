import React, { useState } from 'react';
import { useTheme } from '../../context/ThemeContext';

interface ResourceLibraryProps {
  category: string;
}

interface Resource {
  title: string;
  type: 'video' | 'article' | 'tool' | 'course';
  source: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  description: string;
  url: string;
  isFree: boolean;
}

const ResourceLibrary: React.FC<ResourceLibraryProps> = ({ category }) => {
  const { theme } = useTheme();
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Mock resources data (replace with real data from backend)
  const resources: Resource[] = [
    {
      title: "Getting Started with Bubble.io",
      type: "video",
      source: "Bubble.io Official",
      difficulty: "beginner",
      description: "A comprehensive introduction to building no-code applications with Bubble.io",
      url: "#",
      isFree: true
    },
    {
      title: "Advanced Automation with Zapier",
      type: "course",
      source: "Zapier Academy",
      difficulty: "intermediate",
      description: "Learn how to create complex automation workflows using Zapier",
      url: "#",
      isFree: false
    },
    {
      title: "No-Code Development Best Practices",
      type: "article",
      source: "No-Code Weekly",
      difficulty: "beginner",
      description: "Essential tips and tricks for building scalable no-code solutions",
      url: "#",
      isFree: true
    },
    {
      title: "Airtable for No-Code Developers",
      type: "tool",
      source: "Airtable",
      difficulty: "beginner",
      description: "The ultimate database tool for no-code applications",
      url: "#",
      isFree: true
    }
  ];

  const filters = [
    { id: 'all', label: 'All Resources' },
    { id: 'video', label: 'Videos' },
    { id: 'article', label: 'Articles' },
    { id: 'tool', label: 'Tools' },
    { id: 'course', label: 'Courses' }
  ];

  const getResourceIcon = (type: string) => {
    switch (type) {
      case 'video':
        return '🎥';
      case 'article':
        return '📄';
      case 'tool':
        return '🛠️';
      case 'course':
        return '📚';
      default:
        return '📌';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner':
        return theme === 'dark' ? 'text-green-400' : 'text-green-600';
      case 'intermediate':
        return theme === 'dark' ? 'text-yellow-400' : 'text-yellow-600';
      case 'advanced':
        return theme === 'dark' ? 'text-red-400' : 'text-red-600';
      default:
        return '';
    }
  };

  const filteredResources = resources.filter(resource => {
    const matchesFilter = activeFilter === 'all' || resource.type === activeFilter;
    const matchesSearch = resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         resource.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Search and Filters */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="w-full md:w-64">
          <input
            type="text"
            placeholder="Search resources..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full px-4 py-2 rounded-lg ${
              theme === 'dark'
                ? 'bg-gray-700 text-white placeholder-gray-400'
                : 'bg-white text-gray-900 placeholder-gray-500'
            } border ${
              theme === 'dark' ? 'border-gray-600' : 'border-gray-300'
            } focus:outline-none focus:ring-2 focus:ring-blue-500`}
          />
        </div>

        <div className="flex flex-wrap gap-2">
          {filters.map(filter => (
            <button
              key={filter.id}
              onClick={() => setActiveFilter(filter.id)}
              className={`px-4 py-2 rounded-lg ${
                activeFilter === filter.id
                  ? theme === 'dark'
                    ? 'bg-blue-600 text-white'
                    : 'bg-blue-500 text-white'
                  : theme === 'dark'
                    ? 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {filter.label}
            </button>
          ))}
        </div>
      </div>

      {/* Resources Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredResources.map((resource, index) => (
          <div
            key={index}
            className={`${
              theme === 'dark' ? 'bg-gray-800' : 'bg-white'
            } rounded-xl p-6 shadow-lg transition-transform duration-200 transform hover:-translate-y-1`}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <span className="text-2xl">{getResourceIcon(resource.type)}</span>
                <div>
                  <h3 className="font-semibold">{resource.title}</h3>
                  <p className={`text-sm ${
                    theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
                  }`}>
                    by {resource.source}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className={`text-sm px-2 py-1 rounded-full ${
                  resource.isFree
                    ? theme === 'dark'
                      ? 'bg-green-900 text-green-200'
                      : 'bg-green-100 text-green-800'
                    : theme === 'dark'
                      ? 'bg-gray-700 text-gray-300'
                      : 'bg-gray-100 text-gray-800'
                }`}>
                  {resource.isFree ? 'Free' : 'Premium'}
                </span>
              </div>
            </div>

            <p className={`text-sm mb-4 ${
              theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
            }`}>
              {resource.description}
            </p>

            <div className="flex items-center justify-between">
              <span className={`text-sm font-medium ${getDifficultyColor(resource.difficulty)}`}>
                {resource.difficulty.charAt(0).toUpperCase() + resource.difficulty.slice(1)}
              </span>
              <a
                href={resource.url}
                target="_blank"
                rel="noopener noreferrer"
                className={`px-4 py-2 rounded-lg ${
                  theme === 'dark'
                    ? 'bg-blue-600 hover:bg-blue-700'
                    : 'bg-blue-500 hover:bg-blue-600'
                } text-white transition-colors duration-200`}
              >
                Access Resource
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ResourceLibrary;

import React, { useState } from 'react';
import { useTheme } from '../../context/ThemeContext';

interface CareerPath {
  category: string;
  roles: string[];
  skills: string[];
  estimatedTime: string;
}

interface LearningPathProps {
  career: CareerPath;
}

interface Module {
  id: string;
  title: string;
  description: string;
  duration: string;
  status: 'completed' | 'in_progress' | 'locked';
  lessons: {
    title: string;
    type: 'video' | 'reading' | 'quiz' | 'project';
    duration: string;
    completed: boolean;
  }[];
}

const LearningPath: React.FC<LearningPathProps> = ({ career }) => {
  const { theme } = useTheme();
  const [expandedModule, setExpandedModule] = useState<string | null>(null);

  // Mock learning path data (replace with real data from backend)
  const modules: Module[] = [
    {
      id: 'foundations',
      title: 'Foundations',
      description: 'Learn the basics of no-code development and automation',
      duration: '2 weeks',
      status: 'in_progress',
      lessons: [
        {
          title: 'Introduction to No-Code Development',
          type: 'video',
          duration: '15 mins',
          completed: true
        },
        {
          title: 'Understanding Automation Principles',
          type: 'reading',
          duration: '30 mins',
          completed: true
        },
        {
          title: 'Basic Tools Overview',
          type: 'video',
          duration: '20 mins',
          completed: false
        },
        {
          title: 'Module Quiz',
          type: 'quiz',
          duration: '15 mins',
          completed: false
        }
      ]
    },
    {
      id: 'tools',
      title: 'Essential Tools',
      description: 'Master the most important no-code tools in the industry',
      duration: '3 weeks',
      status: 'locked',
      lessons: [
        {
          title: 'Bubble.io Fundamentals',
          type: 'video',
          duration: '45 mins',
          completed: false
        },
        {
          title: 'Zapier Integration Basics',
          type: 'reading',
          duration: '30 mins',
          completed: false
        },
        {
          title: 'Build Your First App',
          type: 'project',
          duration: '2 hours',
          completed: false
        }
      ]
    },
    {
      id: 'advanced',
      title: 'Advanced Concepts',
      description: 'Take your skills to the next level with advanced techniques',
      duration: '4 weeks',
      status: 'locked',
      lessons: [
        {
          title: 'Complex Workflows',
          type: 'video',
          duration: '1 hour',
          completed: false
        },
        {
          title: 'Data Management',
          type: 'reading',
          duration: '45 mins',
          completed: false
        },
        {
          title: 'Final Project',
          type: 'project',
          duration: '4 hours',
          completed: false
        }
      ]
    }
  ];

  const getLessonIcon = (type: string) => {
    switch (type) {
      case 'video':
        return '🎥';
      case 'reading':
        return '📖';
      case 'quiz':
        return '✍️';
      case 'project':
        return '🛠️';
      default:
        return '📌';
    }
  };

  const getModuleStatus = (status: Module['status']) => {
    switch (status) {
      case 'completed':
        return {
          icon: '✅',
          text: 'Completed',
          class: theme === 'dark' ? 'text-green-400' : 'text-green-600'
        };
      case 'in_progress':
        return {
          icon: '🔄',
          text: 'In Progress',
          class: theme === 'dark' ? 'text-blue-400' : 'text-blue-600'
        };
      case 'locked':
        return {
          icon: '🔒',
          text: 'Locked',
          class: theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
        };
      default:
        return {
          icon: '📌',
          text: 'Unknown',
          class: ''
        };
    }
  };

  return (
    <div className="space-y-6">
      {modules.map((module) => (
        <div
          key={module.id}
          className={`${
            theme === 'dark' ? 'bg-gray-800' : 'bg-white'
          } rounded-xl shadow-lg overflow-hidden`}
        >
          {/* Module Header */}
          <div
            onClick={() => setExpandedModule(
              expandedModule === module.id ? null : module.id
            )}
            className={`p-6 cursor-pointer ${
              module.status === 'locked'
                ? theme === 'dark'
                  ? 'bg-gray-800'
                  : 'bg-gray-50'
                : theme === 'dark'
                  ? 'bg-gray-700'
                  : 'bg-white'
            }`}
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-semibold mb-2">{module.title}</h3>
                <p className={`${
                  theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                }`}>
                  {module.description}
                </p>
                <div className="flex items-center gap-4 mt-2">
                  <span className={`text-sm ${
                    theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
                  }`}>
                    {module.duration}
                  </span>
                  <span className={`text-sm ${getModuleStatus(module.status).class}`}>
                    {getModuleStatus(module.status).icon} {getModuleStatus(module.status).text}
                  </span>
                </div>
              </div>
              <span className={`text-2xl transform transition-transform ${
                expandedModule === module.id ? 'rotate-180' : ''
              }`}>
                ⌄
              </span>
            </div>
          </div>

          {/* Module Content */}
          {expandedModule === module.id && (
            <div className={`${
              theme === 'dark' ? 'bg-gray-800' : 'bg-white'
            } border-t ${
              theme === 'dark' ? 'border-gray-700' : 'border-gray-200'
            }`}>
              {module.lessons.map((lesson, index) => (
                <div
                  key={index}
                  className={`p-4 flex items-center justify-between ${
                    index !== module.lessons.length - 1
                      ? theme === 'dark'
                        ? 'border-b border-gray-700'
                        : 'border-b border-gray-200'
                      : ''
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <span className="text-xl">{getLessonIcon(lesson.type)}</span>
                    <div>
                      <h4 className="font-medium">{lesson.title}</h4>
                      <span className={`text-sm ${
                        theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
                      }`}>
                        {lesson.duration}
                      </span>
                    </div>
                  </div>
                  {lesson.completed ? (
                    <span className="text-green-500">✓</span>
                  ) : (
                    <button
                      className={`px-4 py-2 rounded-lg ${
                        module.status === 'locked'
                          ? theme === 'dark'
                            ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                            : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                          : theme === 'dark'
                            ? 'bg-blue-600 hover:bg-blue-700 text-white'
                            : 'bg-blue-500 hover:bg-blue-600 text-white'
                      }`}
                      disabled={module.status === 'locked'}
                    >
                      Start
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default LearningPath;

export { default as Dashboard } from './Dashboard';
export { default as ProgressStats } from './ProgressStats';
export { default as NextSteps } from './NextSteps';
export { default as LearningPath } from './LearningPath';
export { default as ResourceLibrary } from './ResourceLibrary';
export { default as CommunitySection } from './CommunitySection';

import React from 'react';
import { useTheme } from '../../context/ThemeContext';

interface CommunitySectionProps {
  category: string;
}

interface CommunityEvent {
  title: string;
  type: 'meetup' | 'webinar' | 'workshop' | 'discussion';
  date: string;
  time: string;
  host: string;
  attendees: number;
  description: string;
}

interface CommunityMember {
  name: string;
  role: string;
  level: string;
  avatar: string;
  isOnline: boolean;
}

const CommunitySection: React.FC<CommunitySectionProps> = ({ category }) => {
  const { theme } = useTheme();

  // Mock community data (replace with real data from backend)
  const upcomingEvents: CommunityEvent[] = [
    {
      title: "No-Code Development Best Practices",
      type: "webinar",
      date: "2024-02-15",
      time: "2:00 PM EST",
      host: "Sarah Johnson",
      attendees: 45,
      description: "Learn essential best practices for building scalable no-code solutions"
    },
    {
      title: "Build Your First App Workshop",
      type: "workshop",
      date: "2024-02-18",
      time: "1:00 PM EST",
      host: "Mike Chen",
      attendees: 25,
      description: "Hands-on workshop for building your first no-code application"
    }
  ];

  const activeMentors: CommunityMember[] = [
    {
      name: "Alex Thompson",
      role: "Senior No-Code Developer",
      level: "Expert",
      avatar: "👨‍💻",
      isOnline: true
    },
    {
      name: "Maria Garcia",
      role: "Automation Specialist",
      level: "Advanced",
      avatar: "👩‍💻",
      isOnline: true
    }
  ];

  const getEventIcon = (type: string) => {
    switch (type) {
      case 'meetup':
        return '🤝';
      case 'webinar':
        return '🎥';
      case 'workshop':
        return '🛠️';
      case 'discussion':
        return '💭';
      default:
        return '📌';
    }
  };

  return (
    <div className="space-y-8">
      {/* Community Stats */}
      <div className={`grid grid-cols-1 md:grid-cols-3 gap-6`}>
        <div className={`${
          theme === 'dark' ? 'bg-gray-800' : 'bg-white'
        } rounded-xl p-6 text-center`}>
          <div className="text-3xl mb-2">👥</div>
          <div className="text-2xl font-bold mb-1">2,500+</div>
          <div className={`text-sm ${
            theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
          }`}>
            Community Members
          </div>
        </div>

        <div className={`${
          theme === 'dark' ? 'bg-gray-800' : 'bg-white'
        } rounded-xl p-6 text-center`}>
          <div className="text-3xl mb-2">🎯</div>
          <div className="text-2xl font-bold mb-1">150+</div>
          <div className={`text-sm ${
            theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
          }`}>
            Learning Together
          </div>
        </div>

        <div className={`${
          theme === 'dark' ? 'bg-gray-800' : 'bg-white'
        } rounded-xl p-6 text-center`}>
          <div className="text-3xl mb-2">🌟</div>
          <div className="text-2xl font-bold mb-1">50+</div>
          <div className={`text-sm ${
            theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
          }`}>
            Active Mentors
          </div>
        </div>
      </div>

      {/* Upcoming Events */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Upcoming Events</h2>
        <div className="space-y-4">
          {upcomingEvents.map((event, index) => (
            <div
              key={index}
              className={`${
                theme === 'dark' ? 'bg-gray-800' : 'bg-white'
              } rounded-xl p-6 transition-transform duration-200 transform hover:-translate-y-1`}
            >
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                  theme === 'dark' ? 'bg-gray-700' : 'bg-gray-100'
                }`}>
                  <span className="text-2xl">{getEventIcon(event.type)}</span>
                </div>

                <div className="flex-grow">
                  <h3 className="font-semibold mb-2">{event.title}</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className={`text-sm ${
                        theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                      }`}>
                        📅 {event.date}
                      </p>
                      <p className={`text-sm ${
                        theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                      }`}>
                        🕒 {event.time}
                      </p>
                    </div>
                    <div>
                      <p className={`text-sm ${
                        theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                      }`}>
                        👤 Host: {event.host}
                      </p>
                      <p className={`text-sm ${
                        theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                      }`}>
                        👥 {event.attendees} attending
                      </p>
                    </div>
                  </div>
                </div>

                <button className={`px-4 py-2 rounded-lg ${
                  theme === 'dark'
                    ? 'bg-blue-600 hover:bg-blue-700'
                    : 'bg-blue-500 hover:bg-blue-600'
                } text-white transition-colors duration-200`}>
                  Join Event
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Active Mentors */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Active Mentors</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {activeMentors.map((mentor, index) => (
            <div
              key={index}
              className={`${
                theme === 'dark' ? 'bg-gray-800' : 'bg-white'
              } rounded-xl p-4 flex items-center gap-4`}
            >
              <div className="relative">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center text-2xl ${
                  theme === 'dark' ? 'bg-gray-700' : 'bg-gray-100'
                }`}>
                  {mentor.avatar}
                </div>
                {mentor.isOnline && (
                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white" />
                )}
              </div>

              <div className="flex-grow">
                <h3 className="font-semibold">{mentor.name}</h3>
                <p className={`text-sm ${
                  theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                }`}>
                  {mentor.role}
                </p>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  theme === 'dark'
                    ? 'bg-gray-700 text-gray-300'
                    : 'bg-gray-100 text-gray-700'
                }`}>
                  {mentor.level}
                </span>
              </div>

              <button className={`px-4 py-2 rounded-lg ${
                theme === 'dark'
                  ? 'bg-gray-700 hover:bg-gray-600'
                  : 'bg-gray-100 hover:bg-gray-200'
              } transition-colors duration-200`}>
                Message
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Community Discussion */}
      <div className={`${
        theme === 'dark' ? 'bg-gray-800' : 'bg-white'
      } rounded-xl p-6`}>
        <h2 className="text-xl font-semibold mb-4">Join the Discussion</h2>
        <p className={`mb-4 ${
          theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
        }`}>
          Connect with fellow learners, share your progress, and get help from the community.
        </p>
        <div className="flex gap-4">
          <button className={`px-6 py-3 rounded-lg ${
            theme === 'dark'
              ? 'bg-blue-600 hover:bg-blue-700'
              : 'bg-blue-500 hover:bg-blue-600'
          } text-white transition-colors duration-200`}>
            Join Discord Community
          </button>
          <button className={`px-6 py-3 rounded-lg ${
            theme === 'dark'
              ? 'bg-gray-700 hover:bg-gray-600'
              : 'bg-gray-100 hover:bg-gray-200'
          } transition-colors duration-200`}>
            View Forum
          </button>
        </div>
      </div>
    </div>
  );
};

export default CommunitySection;

import React from 'react';
import { useTheme } from '../../context/ThemeContext';

interface CareerPath {
  category: string;
  roles: string[];
  skills: string[];
  estimatedTime: string;
}

interface ProgressStatsProps {
  career: CareerPath;
}

const ProgressStats: React.FC<ProgressStatsProps> = ({ career }) => {
  const { theme } = useTheme();

  // Mock progress data (replace with real data from backend)
  const progress = {
    overallProgress: 35,
    skillsProgress: {
      completed: 2,
      total: career.skills.length
    },
    streakDays: 7,
    hoursSpent: 24,
    nextMilestone: "Complete Basic Tools Module"
  };

  return (
    <div className={`${
      theme === 'dark' ? 'bg-gray-700' : 'bg-gray-50'
    } rounded-xl p-6`}>
      <h2 className="text-xl font-semibold mb-6">Your Progress</h2>

      {/* Overall Progress */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-2">
          <span className={theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}>
            Overall Progress
          </span>
          <span className="font-semibold">{progress.overallProgress}%</span>
        </div>
        <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-blue-500 to-indigo-500"
            style={{ width: `${progress.overallProgress}%` }}
          />
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4">
        {/* Skills Progress */}
        <div className={`${
          theme === 'dark' ? 'bg-gray-800' : 'bg-white'
        } rounded-lg p-4`}>
          <div className="text-3xl font-bold mb-1">
            {progress.skillsProgress.completed}/{progress.skillsProgress.total}
          </div>
          <div className={`text-sm ${
            theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
          }`}>
            Skills Completed
          </div>
        </div>

        {/* Learning Streak */}
        <div className={`${
          theme === 'dark' ? 'bg-gray-800' : 'bg-white'
        } rounded-lg p-4`}>
          <div className="text-3xl font-bold mb-1">
            {progress.streakDays} 🔥
          </div>
          <div className={`text-sm ${
            theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
          }`}>
            Day Streak
          </div>
        </div>

        {/* Hours Spent */}
        <div className={`${
          theme === 'dark' ? 'bg-gray-800' : 'bg-white'
        } rounded-lg p-4`}>
          <div className="text-3xl font-bold mb-1">
            {progress.hoursSpent}h
          </div>
          <div className={`text-sm ${
            theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
          }`}>
            Total Hours
          </div>
        </div>

        {/* Next Milestone */}
        <div className={`${
          theme === 'dark' ? 'bg-gray-800' : 'bg-white'
        } rounded-lg p-4`}>
          <div className="text-sm font-semibold mb-1">Next Milestone</div>
          <div className={`text-sm ${
            theme === 'dark' ? 'text-gray-400' : 'text-gray-500'
          }`}>
            {progress.nextMilestone}
          </div>
        </div>
      </div>

      {/* Motivation Quote */}
      <div className={`mt-6 p-4 rounded-lg border ${
        theme === 'dark'
          ? 'border-gray-600 bg-gray-800'
          : 'border-gray-200 bg-white'
      }`}>
        <p className={`text-sm italic ${
          theme === 'dark' ? 'text-gray-300' : 'text-gray-600'
        }`}>
          "Small steps every day lead to massive progress over time. Keep going! 💪"
        </p>
      </div>
    </div>
  );
};

export default ProgressStats;

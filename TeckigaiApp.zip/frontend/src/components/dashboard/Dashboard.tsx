import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useTheme } from '../../context/ThemeContext';
import ProgressStats from './ProgressStats';
import NextSteps from './NextSteps';
import LearningPath from './LearningPath';
import ResourceLibrary from './ResourceLibrary';
import CommunitySection from './CommunitySection';
import Logo from '../common/Logo';

interface CareerPath {
  category: string;
  roles: string[];
  skills: string[];
  estimatedTime: string;
}

interface DashboardState {
  selectedCareer: CareerPath;
  allCareers: CareerPath[];
}

const Dashboard: React.FC = () => {
  const { theme } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Check authentication
  useEffect(() => {
    const isAuthenticated = localStorage.getItem('isAuthenticated');
    if (!isAuthenticated) {
      navigate('/login');
    }
  }, [navigate]);

  const dashboardState = location.state as DashboardState;
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  const getEmoji = (category: string): string => {
    const emojiMap: { [key: string]: string } = {
      "No-Code Development": "🛠️",
      "Content Creation": "✍️",
      "Design": "🎨",
      "Coding": "💻",
      "Support": "🤝"
    };
    return emojiMap[category] || "🎯";
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: '📊' },
    { id: 'learning', label: 'Learning Path', icon: '📚' },
    { id: 'resources', label: 'Resources', icon: '🎯' },
    { id: 'community', label: 'Community', icon: '👥' },
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <ProgressStats career={dashboardState.selectedCareer} />
            <NextSteps career={dashboardState.selectedCareer} />
          </div>
        );
      case 'learning':
        return <LearningPath career={dashboardState.selectedCareer} />;
      case 'resources':
        return <ResourceLibrary category={dashboardState.selectedCareer.category} />;
      case 'community':
        return <CommunitySection category={dashboardState.selectedCareer.category} />;
      default:
        return null;
    }
  };

  return (
    <div className={`min-h-screen ${
      theme === 'dark' ? 'bg-gray-900 text-white' : 'bg-white text-gray-900'
    }`}>
      {/* Top Navigation Bar */}
      <nav className={`${
        theme === 'dark' ? 'bg-gray-800' : 'bg-white'
      } shadow-lg`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              {/* Logo/Brand */}
              <div className="flex-shrink-0 flex items-center">
                <Logo size="small" />
              </div>
            </div>

            {/* User Menu */}
            <div className="flex items-center">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className={`rounded-full w-10 h-10 flex items-center justify-center ${
                  theme === 'dark' ? 'bg-gray-700' : 'bg-gray-100'
                }`}
              >
                {user.name?.[0]?.toUpperCase() || '👤'}
              </button>
              
              {isMenuOpen && (
                <div className={`absolute right-4 top-16 w-48 rounded-md shadow-lg py-1 ${
                  theme === 'dark' ? 'bg-gray-800' : 'bg-white'
                } ring-1 ring-black ring-opacity-5`}>
                  <button
                    onClick={() => navigate('/profile')}
                    className={`block w-full text-left px-4 py-2 text-sm ${
                      theme === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-100'
                    }`}
                  >
                    Your Profile
                  </button>
                  <button
                    className={`block w-full text-left px-4 py-2 text-sm ${
                      theme === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-100'
                    }`}
                  >
                    Settings
                  </button>
                  <button
                    onClick={() => {
                      localStorage.removeItem('isAuthenticated');
                      localStorage.removeItem('user');
                      navigate('/login');
                    }}
                    className={`block w-full text-left px-4 py-2 text-sm ${
                      theme === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-100'
                    }`}
                  >
                    Sign out
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Career Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <span className="text-3xl">
              {getEmoji(dashboardState.selectedCareer.category)}
            </span>
            <h1 className="text-3xl font-bold">
              {dashboardState.selectedCareer.category}
            </h1>
          </div>
          <p className={`${
            theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
          }`}>
            Your journey to becoming a {dashboardState.selectedCareer.roles[0]}
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="mb-8">
          <nav className={`flex space-x-4 ${
            theme === 'dark' ? 'bg-gray-800' : 'bg-gray-100'
          } rounded-lg p-2`}>
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 rounded-lg flex items-center space-x-2 ${
                  activeTab === tab.id
                    ? theme === 'dark'
                      ? 'bg-gray-700 text-white'
                      : 'bg-white text-gray-900 shadow'
                    : theme === 'dark'
                      ? 'text-gray-400 hover:text-white hover:bg-gray-700'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-white'
                }`}
              >
                <span>{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* Tab Content */}
        <div className={`${
          theme === 'dark' ? 'bg-gray-800' : 'bg-white'
        } rounded-lg shadow-lg p-6`}>
          {renderTabContent()}
        </div>
      </main>
    </div>
  );
};

export { Dashboard as default };

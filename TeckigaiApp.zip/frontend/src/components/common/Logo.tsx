import React from 'react';
import { useTheme } from '../../context/ThemeContext';

interface LogoProps {
  size?: 'small' | 'medium' | 'large';
  showText?: boolean;
}

const Logo: React.FC<LogoProps> = ({ size = 'medium', showText = true }) => {
  const { theme } = useTheme();
  
  const sizeClasses = {
    small: 'h-8',
    medium: 'h-12',
    large: 'h-16'
  };

  return (
    <div className="flex items-center gap-3">
      <svg
        className={`${sizeClasses[size]} ${
          theme === 'dark' ? 'text-white' : 'text-gray-900'
        }`}
        viewBox="0 0 64 64"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M32 4L4 18V46L32 60L60 46V18L32 4Z"
          stroke="currentColor"
          strokeWidth="4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M32 32L16 24M32 32L48 24M32 32V48"
          stroke="currentColor"
          strokeWidth="4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle
          cx="16"
          cy="24"
          r="4"
          fill="none"
          stroke="currentColor"
          strokeWidth="4"
        />
        <circle
          cx="48"
          cy="24"
          r="4"
          fill="none"
          stroke="currentColor"
          strokeWidth="4"
        />
        <circle
          cx="32"
          cy="48"
          r="4"
          fill="none"
          stroke="currentColor"
          strokeWidth="4"
        />
      </svg>
      {showText && (
        <span className={`font-bold ${
          size === 'small' ? 'text-xl' :
          size === 'medium' ? 'text-2xl' :
          'text-4xl'
        }`}>
          Teckigai
        </span>
      )}
    </div>
  );
};

export default Logo;
